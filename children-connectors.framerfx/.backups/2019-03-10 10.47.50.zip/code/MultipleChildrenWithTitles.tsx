import * as React from "react";
import { PropertyControls, ControlType } from "framer";

const style: React.CSSProperties = {
  height: "100%",
  display: "grid",
  gridTemplateColumns: "auto auto auto",
  alignItems: "center",
  justifyContent: "center",
  textAlign: "center",
  color: "#8855FF",
  background: "rgba(136, 85, 255, 0.1)",
  overflow: "hidden"
};

// Define type of property
interface Props {
  ceo: React.ReactNode;
  cto: React.ReactNode;
  coo: React.ReactNode;
}

export class MultipleChildrenWithTitles extends React.Component<Props> {
  // Set default properties
  static defaultProps = {};

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    ceo: {
      type: ControlType.ComponentInstance,
      title: "CEO"
    },
    cto: {
      type: ControlType.ComponentInstance,
      title: "CTO"
    },
    coo: {
      type: ControlType.ComponentInstance,
      title: "COO"
    }
    // children: {
    //   type: ControlType.Array,
    //   title: "Content",
    //   propertyControl: {
    //     type: ControlType.ComponentInstance,
    //     title: "Page"
    //   }
    // }
  };
  // Overwrite the default "position: absolute"
  cloneElement = e =>
    React.cloneElement(e[0], {
      style: { position: "relative", transform: "translate(0,0)" }
    });

  render() {
    const { ceo, cto, coo } = this.props;
    console.log(this.props);

    return (
      <div style={style}>
        <div>CEO</div>
        <div>CTO</div>
        <div>COO</div>
        {this.cloneElement(ceo)}
        {this.cloneElement(cto)}
        {this.cloneElement(coo)}
      </div>
    );
  }
}
